	 <style>
	 	.text_in_put
	 	{
	 		width: 80%;
	 	}
		.tr-center 
		{
			text-align: center;
		}
	 </style>
	 <table>
	 	<tr class="tr-center"><th><span style=" font-size: 30px;font-family: Courier New;">Template Style 8 Available In Pro Plugin</span></th></tr>
	 	<tr><th>&nbsp </th></tr>
	 	<tr class="tr-center">
	 		<td>

	 			<img src="<?php echo WEBLIZAR_ABOUT_ME_PLUGIN_URL.'settings/images/temp8.png'; ?>"   />

	 		</td>
	 	</tr>
        <tr class="tr-center">
			<td>
				<a href="http://demo.weblizar.com/about-author-pro/" target="_blank" class="button button-primary button-hero">Check Demo Now</a>
				<a href="https://weblizar.com/plugins/about-author-pro/" target="_blank" class="button button-primary button-hero">Upgrade To Pro</a>
			</td>
		</tr>
	 </table>
